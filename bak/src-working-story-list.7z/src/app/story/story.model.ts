export interface Story {
id: string,
question: string,
answers: string[],
}
