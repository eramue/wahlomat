import { StoryService } from './../story.service';
import { Story } from './../story.model';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-story-list',
  templateUrl: './story-list.component.html',
  styleUrls: ['./story-list.component.css']
})
export class StoryListComponent implements OnInit {
  stories: Story[] = [];
  private subscription: Subscription;
  parties: string[];

  constructor(public storyService: StoryService) {}
  ngOnDestroy(): void {
    this.subscription.unsubscribe;
  }

  ngOnInit(): void {
    this.parties=  this.storyService.getParties();
    this.stories = this.storyService.getStories();
    this.subscription = this.storyService
      .getStoryUpdateListener()
      .subscribe((stories: Story[]) => {
        this.stories = stories;
      });
  }

  onDelete(id: string) {
    this.storyService.deletePost(id);
  }

}
