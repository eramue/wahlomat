import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StoryCreateComponent } from './story/story-create/story-create.component';
import { StoryListComponent } from './story/story-list/story-list.component';

const routes: Routes = [
  { path: '', component: StoryListComponent },
  { path: 'create', component: StoryCreateComponent },
  { path: 'edit/:storyId', component: StoryListComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
