export interface Party {
  name: string;
}
