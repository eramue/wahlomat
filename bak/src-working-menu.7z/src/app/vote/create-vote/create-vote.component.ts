import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-vote',
  templateUrl: './create-vote.component.html',
  styleUrls: ['./create-vote.component.css']
})
export class CreateVoteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
