import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

import { Story } from './story.model';

@Injectable({providedIn: 'root'})
export class StoryService {
  private stories: Story[] = [];
  private storiesUpdated = new Subject<Story[]>();

  getStories() {
    return [...this.stories];
  }

  getPostUpdateListener() {
    return this.storiesUpdated.asObservable();
  }

  addStory(question: string, answers: string[]) {
    const story: Story = {question: question, answers: answers, id: null};
    this.stories.push(story);
    this.storiesUpdated.next([...this.stories]);
  }

  addStory2(story: Story) {
   this.stories.push(story);
    this.storiesUpdated.next([...this.stories]);
  }
}
