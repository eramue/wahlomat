import { Component, OnInit } from '@angular/core';
import { StoryService } from 'src/app/story/story.service';
import { Vote } from 'src/app/vote/vote.model';
import { Story } from '../../story/story.model';

@Component({
  selector: 'app-create-vote',
  templateUrl: './create-vote.component.html',
  styleUrls: ['./create-vote.component.css'],
})
export class CreateVoteComponent implements OnInit {
  votes: Vote[] = [];
  checked = false;
  showParty: boolean= false;
  parties: string[];
  constructor(public storyService: StoryService) {
    this.parties = this.storyService.getParties();
  }

  ngOnInit(): void {
    const newVote: Vote = {
      id: '1',
      user: 'Rainer',
      story: {
        id: '11',
        thema: 'Klima',
        question: 'menschengemacht?',
        answers: ['a1', 'b1', 'c1', 'd1', 'e1', 'f1'],
      },
      value: [0,0,0,0,0,0],
    };
    this.votes.push(newVote);
  }

  toggleShowParty(id: string) {
    this.showParty= !this.showParty;
  }

  getLabel(pos: number, party: string) {
    if (this.showParty) {
      return party;
    } else {
      return pos;
    }
  }
}
