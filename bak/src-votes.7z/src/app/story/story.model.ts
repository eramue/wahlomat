export interface Story {
id: string,
thema: string,
question: string,
answers: string[],
}
