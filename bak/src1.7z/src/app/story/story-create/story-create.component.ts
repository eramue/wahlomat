import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Story } from '../story.model';

@Component({
  selector: 'app-story-create',
  templateUrl: './story-create.component.html',
  styleUrls: ['./story-create.component.css'],
})
export class StoryCreateComponent implements OnInit {
  private mode = 'create';
  private storyId: string;
  story: Story;
  constructor(public route: ActivatedRoute) {}

  ngOnInit(): void {}

  onAddStory(form: NgForm) {
    if (!form.valid) {
      return;
    }
    if (this.mode == 'create') {
      const newStory: Story = {
        id: null,
        question: form.value.question,
        answers: form.value.answer,
      };
      this.story = newStory;
      //this.postsService.addPost2(newPost);
      form.resetForm();
    } else {
      // this.postsService.updatePost(this.storyId,form.value.question, form.value.answer);
    }
  }
}
