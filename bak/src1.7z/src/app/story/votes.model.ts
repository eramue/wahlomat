export interface Vote
 {
  roundId: number;
  user: string;
  storyId: number;
  value: number[];
}
