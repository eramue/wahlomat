import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StoryCreateComponent } from './story/story-create/story-create.component';

const routes: Routes = [
  { path: 'create', component: StoryCreateComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
